# Organized
Description:                      “Organized” is a desktop application thought to enhance 
                                  performance, save time and assist users of different 
                                  backgrounds in keeping everything easily accessible. 
                                  It provides an effective method to organize 
                                  any chosen folder, deal with duplicate copies of 
                                  documents and assign tags to files/folders.

Current status:                   Working 
   
Tools used:                       To create the GUI, NetBeans IDE 8.2 was used. All the other classes 
                                  were created using JDK 1.8

Libraries:                        -java.io
                                  -java.nio.file
                                  -java.awt
                                  -javax.swing
                                  -java.security
Classes:                          
                                          -OFile
                                          -Tag
                                          -Mainprogram
                                          -WatchDir 
                                          -Organize 
                                          -Finder 
                                          -TreePanel
                                          -SimpleTreePanel 	
                                          -Organized
                                          -MyJPanel
                                          -AudioVideoFileFilter
                                          -DocumentFileFilter 
                                          -PowerPointFileFilter, 
					  -PdfFileFilter, 
                                          -WordFileFilter
                                          -FileFillterByDate 
                                          -ImageFileFilter
					  -JavaFilter	
